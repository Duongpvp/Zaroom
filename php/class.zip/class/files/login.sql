-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 22, 2022 at 10:05 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `login`
--

-- --------------------------------------------------------

--
-- Table structure for table `class`
--

CREATE TABLE `class` (
  `id_class` int(3) NOT NULL,
  `name_class` varchar(30) NOT NULL,
  `time` datetime NOT NULL,
  `code` varchar(6) NOT NULL,
  `teacher` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class`
--

INSERT INTO `class` (`id_class`, `name_class`, `time`, `code`, `teacher`) VALUES
(1, '1', '2022-03-18 02:49:16', '', ''),
(2, 'ATHT', '2022-03-18 02:49:55', '', ''),
(3, 'ANM', '2022-03-18 02:49:55', '', ''),
(4, '4', '2022-03-18 02:50:16', '', ''),
(5, 'LTW', '2022-03-18 02:50:16', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `class_user`
--

CREATE TABLE `class_user` (
  `id_class` int(3) NOT NULL,
  `id_user` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `class_user`
--

INSERT INTO `class_user` (`id_class`, `id_user`) VALUES
(5, 11),
(1, 12),
(3, 12),
(1, 13),
(4, 13),
(5, 14),
(2, 14),
(1, 11),
(4, 11);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id_msg` int(11) NOT NULL,
  `user_from` varchar(100) NOT NULL,
  `body` varchar(500) NOT NULL,
  `date_sent` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`id_msg`, `user_from`, `body`, `date_sent`) VALUES
(70, 'duong891109@gmail.com', '123', '2022-03-22 08:44:12'),
(71, 'duong891109@gmail.com', 'This mess', '2022-03-22 08:45:29'),
(72, 'duong891109@gmail.com', '123asd', '2022-03-22 15:09:21'),
(73, 'duong891109@gmail.com', 'what sup', '2022-03-22 15:20:29'),
(74, 'duong891109@gmail.com', 'Chao bạn', '2022-03-22 15:20:42'),
(75, 'duong891109@gmail.com', 'T&ocirc;i t&ecirc;n dương', '2022-03-22 15:21:22'),
(76, 'duong891109@gmail.com', 'Alo', '2022-03-22 15:23:28'),
(77, 'luanlt632000@gmail.com', 'alo', '2022-03-22 15:24:42'),
(78, 'luanlt632000@gmail.com', 'G&igrave; dậy', '2022-03-22 15:54:12');

-- --------------------------------------------------------

--
-- Table structure for table `relation`
--

CREATE TABLE `relation` (
  `id` int(3) NOT NULL,
  `r_from` varchar(50) NOT NULL,
  `r_to` varchar(50) NOT NULL,
  `request` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `relation`
--

INSERT INTO `relation` (`id`, `r_from`, `r_to`, `request`) VALUES
(24, 'luanlt632000@gmail.com', 'luanb1807573@student.ctu.edu.vn', 0),
(25, 'luanlt632000@gmail.com', 'duong891109@gmail.com', 0),
(33, '2', 'duong891109@gmail.com', 0);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `code` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `code`) VALUES
(8, 'fds', 'luanlt632000@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', ''),
(10, 'ád', 'luanb1807573@student.ctu.edu.vn', 'c4ca4238a0b923820dcc509a6f75849b', ''),
(11, '1', '1@1', 'c4ca4238a0b923820dcc509a6f75849b', ''),
(12, '2', '2', '', ''),
(13, '3', '3', '', ''),
(14, 'Duong', 'duong891109@gmail.com', 'c4ca4238a0b923820dcc509a6f75849b', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `class`
--
ALTER TABLE `class`
  ADD PRIMARY KEY (`id_class`);

--
-- Indexes for table `class_user`
--
ALTER TABLE `class_user`
  ADD KEY `classes` (`id_class`),
  ADD KEY `users` (`id_user`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id_msg`);

--
-- Indexes for table `relation`
--
ALTER TABLE `relation`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `class`
--
ALTER TABLE `class`
  MODIFY `id_class` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id_msg` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=79;

--
-- AUTO_INCREMENT for table `relation`
--
ALTER TABLE `relation`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `class_user`
--
ALTER TABLE `class_user`
  ADD CONSTRAINT `classes` FOREIGN KEY (`id_class`) REFERENCES `class` (`id_class`),
  ADD CONSTRAINT `users` FOREIGN KEY (`id_user`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

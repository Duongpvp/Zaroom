<?php
session_start();
include ('../../includes/config.php');
if (isset($_GET['idClass'])) {
    $_SESSION['idClass'] = $_GET['idClass'];
    $_SESSION['nameClass'] = $_GET['nameCla'];
}
$query = mysqli_query($conn, "SELECT * FROM users WHERE id='{$_SESSION['SESSION_ID']}'");
if (mysqli_num_rows($query) > 0) {
    $row = mysqli_fetch_assoc($query);
    $id_user = $row['id'];
    $email = $row['email'];
}
$sql = "SELECT * FROM `relation` WHERE r_to = '$email' AND request = 1";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="en">

<body>

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title><?php echo $_SESSION['nameClass']; ?></title>
        <link rel="stylesheet" href="../../chat_dversion/css/style.css" />
        <link rel="stylesheet" href="./style.css" />

        <style>
            .img-bt {
                width: 9%;
                height: 30px;
                margin-top: 7%;

            }

            .thea {
                height: 60px;
                border: 1px solid;
                border-radius: 5px;
                font-size: 30px;
                padding: 3%;
                color: black;
                background-color: #E6E6E6;
            }

            .div-bt {
                width: 18%;
                height: 50px;
                margin-left: 1%;
            }

            .bt {
                padding: 2%;
            }

            a.thea:hover,
            a.thea:focus {
                background-color: green;
            }
            img{
                width: 20px;
                height: 20px;
            }
        </style>
    </head>
    <div class="class-header">
        <ul style="display:flex;">
            <li><button class="button" onclick="window.location='./class_teacher.php';"><span>Trở về</span></button></li>
            <li id="li"><span class="nameCla"><?php echo $_SESSION['nameClass']; ?> </span> </li>
        </ul>
    </div>
    <div class='div-bt'>
        <a class="thea" href="./post.php"><img src="../../images/homework.png" alt="image" class="img-bt"><span class="bt">Thêm bài tập</span></a>
    </div>
</body>

</html>
<?php
echo "<div class='main'>
     ";
$result = $conn->query("SELECT * FROM `class`, `ex_class`,`exercise` WHERE ex_class.id_class_r=$_SESSION[idClass] 
            AND exercise.id_ex=ex_class.id_ex_r AND ex_class.id_class_r=class.id_class");
echo "<table class='post-table'>
    
            <td id='list'> 
            <h3 id='name-list'><b>Danh sách bài tập</b><br></h3>";
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "
                 <h4><b>$row[title_ex]</b></h4>";
    }
}

echo " </td>
            <td style='width:80% ;border-left:solid; border-color: gray;'>
    ";
// echo "<div class='post'>";
$result = $conn->query("SELECT * FROM `class`, `ex_class`,`exercise` WHERE ex_class.id_class_r=$_SESSION[idClass] 
            AND exercise.id_ex=ex_class.id_ex_r AND ex_class.id_class_r=class.id_class");
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        echo "<div class='main-post'>
                    <div class='title-post'>
                        <h3><b>$row[title_ex]</b></h3>";
                        $x = $row['id_ex'];
                      echo"  </div>
                      <div class='option'>
                    <a href='./edit_ex.php?idEx=$row[id_ex]'>Sửa</a>
                    <a href='./delete_ex.php'>Xóa</a>
                    <a href='./grade.php'>Chấm điểm</a>
                    </div>
                    <div class='content-post'>
                        $row[content_ex]
                    </div>
                    
                    <div class='file-post'>";
                $result1 = $conn->query("SELECT * FROM `exercise`,`file`,`file_exercise` WHERE file.id_file=file_exercise.id_file_exercise AND file_exercise.id_exercise = exercise.id_ex AND file_exercise.id_exercise = $x" );
                if($result1->num_rows > 0){
                    while($row1=$result1->fetch_assoc()){
                    $typePath = pathinfo($row1['path_file'],PATHINFO_EXTENSION);
                    if($typePath!=null){
                    switch ($typePath){
                        case "doc":
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/doc.png'> $row1[path_file]</a>";
                            break;
                        case "docx":
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/doc.png'> $row1[path_file]</a>";
                            break;
                        case "xlsx":
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/excel.jpg'> $row1[path_file]</a>";
                            break;
                        case "jpg":
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/image.jpg'> $row1[path_file]</a>";
                            break;
                        case "png":
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/image.jpg'> $row1[path_file]</a>";
                            break;
                        case "zip":
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/zip.jpg'> $row1[path_file]</a>";
                            break;
                        case "rar":
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/zip.jpg'> $row1[path_file]</a>";
                            break;
                        case "pdf":
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/pdf.png'> $row1[path_file]</a>";
                            break;
                        default:
                            echo "<a href='view_file.php?filename=$row1[path_file]'><img src='./img/default.png'> $row1[path_file]</a>";
                        
                    }
                }
            }
        }
                echo "</div>
                </div>
                
            ";
    }
    //echo "</div>
    echo "</td>";
    echo "</div></table>";
}
?>